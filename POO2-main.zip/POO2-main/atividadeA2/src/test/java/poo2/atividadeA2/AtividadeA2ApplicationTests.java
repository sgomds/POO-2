package poo2.atividadeA2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtividadeA2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
